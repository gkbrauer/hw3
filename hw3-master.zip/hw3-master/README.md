# Homework #3 (20 points)

**DUE: Feb 28, 6:00pm**

Instructions:

1. Download this repository, rename it as "hw3", and put it under you "code" folder.
2. Open `index.html` in your browser for assignment instructions.
3. Use the GitHub app to convert your "hw3" folder into a local repository and publish it under your GitHub account as "hw3".

Use Canvas to turn in your assignment by providing the URL to your repository.
